#include "renderarea.h"

RenderArea::RenderArea(QWidget *parent):QGraphicsScene(parent)

{


    press=false;
    drawn=false;
    pen1=QPen();
    pen1.setWidth(1);
    point=0;

}
//permet davoir 1er et 2eme point lors d'un clic de souris
void RenderArea::mousePressEvent(QGraphicsSceneMouseEvent  *event)
{
    drawn=true;

    if(event->buttons()& Qt::LeftButton & !press  ){
        point1=event->scenePos();
        press=true;
    }

}

void RenderArea::mouseReleaseEvent(QGraphicsSceneMouseEvent  *event)
{
    press=false;
    point=0;
}
//dessine les différents formes
void RenderArea::mouseMoveEvent(QGraphicsSceneMouseEvent  *event)
{
    if(press && (event->buttons() & Qt::LeftButton)){
        switch(myShape){

        case Line:
            drawLine(event->scenePos());
            break;
         case Rect:
            drawRect(event->scenePos());
            break;
         case Cercle:
            drawCircle(event->scenePos());
            break;
         case Brosse:
            suppr(event->scenePos());
            break;
         case Libre:
            free(event->scenePos());
            break;



        }
    }
}
void RenderArea::drawLine(QPointF pointFinal)
{
    if(point){
        this->removeItem(point);
       }
    point=this->addLine(QLineF(point1,pointFinal),pen1);
}

void RenderArea::drawCircle(QPointF pointFinal)
{
    if(point)
        this->removeItem(point);

QRectF newRect(point1,pointFinal);
point=this->addEllipse(newRect,pen1);
}

void RenderArea::drawRect(QPointF pointFinal)
{
    if(point1.x()<=pointFinal.x()){
        x1 = point1.x();
        x2 = pointFinal.x();
    }
    else{
        x1 = pointFinal.x();
        x2 = point1.x();
    }
    if(point1.y()<=pointFinal.y()){
         y1 = point1.y();
         y2 = pointFinal.y();
    }
    else{
         y1 = pointFinal.y();
         y2 = point1.y();
    }
    width=(x2 - x1);
    height=(y2 - y1);
    QRectF newRect1(x1, y1,width ,height );
    point=this->addRect(newRect1,pen1);
}

void RenderArea::free(QPointF pointFinal)
{
    addLine(QLineF(point1,pointFinal),pen1);
    point1=pointFinal;

}

void RenderArea::suppr(QPointF pointFinal)
{
    QPen p(pen1);
    p.setColor(Qt::white);
    addLine(QLineF(point1,pointFinal),p);
    point1=pointFinal;
}

void RenderArea::setDrawn(bool d)
{
    drawn=d;
}
void RenderArea::setShape(Shape shape)
{
    this->myShape = shape;
    update();
}

void RenderArea::setPen(int i)
{
    this->pen1.setWidth(i+2);
    update();
}


void RenderArea:: setPenColor (QColor c)
{
    this->pen1.setColor(c);
    update();
}


