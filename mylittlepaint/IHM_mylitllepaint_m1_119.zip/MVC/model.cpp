#include "model.h"

#include <QFile>
#include <QDebug>

Model::Model()
{
}


bool Model::readFile(const QString &filename)
{
    qDebug() << "Model reading file" << filename;
    buffer.clear();

    if (!QFile::exists(filename)) {
        qDebug() << "Model error file" << filename << "does not exist";
        return false;
    }

    QFile f(filename);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Model error reading file" << filename;
        return false;
    }
    buffer = QString(f.readAll());
    return true;
}


const QString &Model::fileContent() const
{
    return buffer;
}



