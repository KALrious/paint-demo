#include "control.h"
#include "model.h"
#include "view.h"

#include <QDebug>


Control::Control(Model *model, View &view) :
    view(view)
{
    this->model = model;
    view.setControl(this);
}

/*void Control::readFile(const QString &filename) const
{
    qDebug() << "Control reading file" << filename;
    if (!model->readFile(filename)) {
        qDebug() << "Control error reading file" << filename;
        view.printFile(QString("ERROR reading file!"));
    }
    else {
        view.printFile(model->fileContent());
    }
}*/


/*void PaintArea::mouseMoveEvent(QMouseEvent *event)
{
    if ((event->buttons() & Qt::LeftButton) && lastPos != QPoint(-1, -1)) {
        if (brushInterface) {
            QPainter painter(&theImage);
            setupPainter(painter);
            const QRect rect = brushInterface->mouseMove(brush, painter, lastPos,
                                                         event->pos());
            update(rect);
        }

        lastPos = event->pos();
    }
}*/

