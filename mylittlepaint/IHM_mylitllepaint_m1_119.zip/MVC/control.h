#ifndef CONTROL_H
#define CONTROL_H

#include <QString>

class Model;
class View;

class Control
{
private:
    Model *model;
    View &view;   //  BOTH attribute types are valid, heterogenity is for *pedagogical* reason
public:
    Control(Model *model, View &view);

    void readFile(const QString &filename) const;

};

#endif // CONTROL_H
