#include "view.h"
#include "ui_view.h"

#include "control.h"

#include <QMessageBox>

View::View(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::View)
{
    ui->setupUi(this);


    //RenderArea set up
    renderArea=new RenderArea(this);

    renderArea->setBackgroundBrush(Qt::white);
    renderArea->setSceneRect(QRectF(0,0,ui->RenderArea->width(),ui->RenderArea->height()));
    ui->RenderArea->updateSceneRect(QRectF(0,0,ui->RenderArea->width(),ui->RenderArea->height()));
    ui->RenderArea->setScene(renderArea);
    nomFichier="No_Name.png";

    // initialiser les boutons
    ui->Line->setCheckable(true);
    ui->Libre->setCheckable(true);
    ui->Rec->setCheckable(true);
    ui->Brosse->setCheckable(true);
    ui->Cercle->setCheckable(true);


    //Par défault on trace des rectangles
     ui->Rec->setChecked(true);









   //Signaux



      QObject::connect(ui->actionNew,SIGNAL(triggered(bool)),this,SLOT(newImage));
      QObject::connect(ui->actionSave,SIGNAL(triggered(bool)),this,SLOT(saveImage()));
      QObject::connect(ui->actionOpen,SIGNAL(triggered(bool)),this,SLOT(openImage()));
      QObject::connect(ui->actionQuit,SIGNAL(triggered(bool)),this,SLOT(quit()));
      QObject::connect(ui->actionPrint,SIGNAL(triggered(bool)),this,SLOT(print()));



     QObject::connect(ui->epaisseur,SIGNAL(valueChanged(int)),ui->spinBox,SLOT(setValue(int)));
     QObject::connect(ui->spinBox,SIGNAL(valueChanged(int)),ui->epaisseur,SLOT(setValue(int)));
     QObject::connect(ui->epaisseur,SIGNAL(valueChanged(int)),renderArea,SLOT(setPenWidth(int)));
     QObject::connect(ui->spinBox,SIGNAL(valueChanged(int)),renderArea,SLOT(setPenWidth(int)));
     QObject::connect(ui->epaisseur,SIGNAL(valueChanged(int)),renderArea,SLOT(setPen(int)));



     QObject::connect(ui->Libre,SIGNAL(clicked()),this,SLOT(on_Libre_clicked()));
     QObject::connect(ui->Rec,SIGNAL(clicked()),this,SLOT(on_Rec_clicked()));
     QObject::connect(ui->Cercle,SIGNAL(clicked()),this,SLOT(on_Cercle_clicked()));
     QObject::connect(ui->Line,SIGNAL(clicked()),this,SLOT(on_Line_clicked()));
     QObject::connect(ui->Brosse,SIGNAL(clicked()),this,SLOT(on_Brosse_clicked()));
     QObject::connect(ui->couleurButtun,SIGNAL(clicked()),this,SLOT(on_pushButton_clicked()));






}





void View::newImage()
{

    renderArea->setDrawn(false);
    renderArea->clear();
}

void View::openImage()
{
    nomFichier = QFileDialog::getOpenFileName(this, tr("Ouvrir une image"),QDir::currentPath(),
                                            tr("Portable Network Graphics  (*.png)"));
    QImage im(nomFichier);
    QGraphicsPixmapItem* imageItem=new QGraphicsPixmapItem(QPixmap::fromImage(im));
      imageItem->setPos(ui->RenderArea->mapToScene(0,0));
     renderArea->addItem(imageItem);



}

void View::saveImage()
{
     nomFichier = QFileDialog::getSaveFileName( this,
           tr("Save workshop"),
           QDir::currentPath(),
           tr("Portable Network Graphics (*.png)") );
     QImage pixmap(ui->RenderArea->width(),ui->RenderArea->height(), QImage::Format_RGB32);
     QPainter p;
     p.begin(&pixmap);
     p.setRenderHint(QPainter::Antialiasing, true);
     renderArea->render(&p);
     p.end();
     pixmap.save(nomFichier, "PNG");



}

void View::print()
{
    QString  nomFichier = QFileDialog::getSaveFileName(this, tr("chemin d'exportation pdf"),QDir::currentPath(), tr("Portable Document Format(.pdf)"));


}

void View::quit()
{
    QApplication::quit();
}


void View::on_Line_clicked()
{
    ui->Line->setChecked(true);
    ui->Rec->setChecked(false);
    ui->Cercle->setChecked(false);
    ui->Libre->setChecked(false);
    ui->Brosse->setChecked(false);
    if(!this->ui->Line->isChecked())
        this->ui->Line->setChecked(true);
    emit this->renderArea->setShape(RenderArea::Line);
    ui->Line->setChecked(RenderArea::Line);}

void View::on_Libre_clicked()
{
    ui->Libre->setChecked(true);
    ui->Rec->setChecked(false);
    ui->Cercle->setChecked(false);
    ui->Line->setChecked(false);
    ui->Brosse->setChecked(false);
    if(!this->ui->Libre->isChecked())
        this->ui->Libre->setChecked(true);
    emit this->renderArea->setShape(RenderArea::Libre);
    ui->Libre->setChecked(RenderArea::Libre);}

void View::on_Rec_clicked()
{
    ui->Rec->setChecked(true);
    ui->Line->setChecked(false);
    ui->Cercle->setChecked(false);
    ui->Libre->setChecked(false);
    ui->Brosse->setChecked(false);
    if(!this->ui->Rec->isChecked())
        this->ui->Rec->setChecked(true);
    emit this->renderArea->setShape(RenderArea::Rect);
    ui->Rec->setChecked(RenderArea::Rect);}

void View::on_Cercle_clicked()
{
    ui->Cercle->setChecked(true);
    ui->Rec->setChecked(false);
    ui->Line->setChecked(false);
    ui->Libre->setChecked(false);
    ui->Brosse->setChecked(false);
    if(!this->ui->Cercle->isChecked())
        this->ui->Cercle->setChecked(true);
    emit this->renderArea->setShape(RenderArea::Cercle);
    ui->Cercle->setChecked(RenderArea::Cercle);
}

void View::on_Brosse_clicked()
{
    ui->Brosse->setChecked(true);
    ui->Rec->setChecked(false);
    ui->Cercle->setChecked(false);
    ui->Libre->setChecked(false);
    ui->Line->setChecked(false);
    if(!this->ui->Brosse->isChecked())
        this->ui->Brosse->setChecked(true);
    emit this->renderArea->setShape(RenderArea::Brosse);
    ui->Brosse->setChecked(RenderArea::Brosse);

}
void View::on_pushButton_clicked()
{
    QColor c=QColorDialog::getColor();

    this->couleur=c;
    emit this->renderArea->setPenColor(c);
}

View::~View()
{
    delete ui;
}







