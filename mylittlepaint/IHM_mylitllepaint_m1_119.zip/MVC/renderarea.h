#ifndef RENDERAREA_H
#define RENDERAREA_H


#include <QMainWindow>
#include <QtGui>
#include <QFileDialog>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QApplication>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QFormLayout>
#include <QGridLayout>
#include <QWidget>
#include <QPainter>
#include <QPainterPath>
#include <QPaintDevice>
#include <QLabel>
#include <QPaintEvent>
#include<QGraphicsItem>
#include<QPainterPath>
#include<QMouseEvent>
#include<QGraphicsSceneMouseEvent>
#include <QGraphicsPathItem>
#include <QColorDialog>
#include<QColor>
#include<QMessageBox>
#include<QFileDialog>
#include <QtPrintSupport/QPrinter>

class View;
class RenderArea : public QGraphicsScene
{
    Q_OBJECT
public:

    // the different shape for drawing
    enum Shape { Line, Libre, Rect, Cercle, Brosse };
    //constructor
   RenderArea(QWidget *parent = 0);


public slots:

    void setPen(int i);
    void setPenColor(QColor c);

    void setDrawn(bool d);
    void setShape(Shape shape);

    void drawCircle(QPointF pointFinal);
    void drawRect(QPointF pointFinal);
    void drawLine(QPointF pointFinal);
    void free(QPointF pointFinal);
    void suppr(QPointF pointFinal);

protected :

    //mouse Events on the renderArea
    void mousePressEvent(QGraphicsSceneMouseEvent  *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent  *event);
    void mouseMoveEvent(QGraphicsSceneMouseEvent  *event);


public :
    int x1;
    int x2;
    int y1;
    int y2;
    int width;
    int height;

    QRectF newRect2;



private:

    QGraphicsItem *point;
    QPointF point1;
    bool press;
    bool drawn;
    Shape myShape;
    QPen pen1;
    QBrush brush;
    bool pressed;
    QPixmap pixmap;
    QGraphicsSceneMouseEvent * mouseEvent;
};

#endif // RENDERAREA_H
