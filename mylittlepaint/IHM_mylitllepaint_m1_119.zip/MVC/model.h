#ifndef MODEL_H
#define MODEL_H

#include <QString>

class Model
{
private:
    QString buffer;
public:
    Model();

    bool readFile(const QString &filename);
    const QString &fileContent() const;
};

#endif // MODEL_H
