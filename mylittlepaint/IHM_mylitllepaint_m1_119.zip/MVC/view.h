#ifndef VIEW_H
#define VIEW_H

#include <QMainWindow>

#include <QtGui>
#include <QFileDialog>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QApplication>
#include <QLineEdit>

#include <QVBoxLayout>
#include <QFormLayout>
#include <QGridLayout>
#include <QWidget>
#include <QPainter>

#include <QLabel>
#include <QComboBox>

#include <QCheckBox>
#include <QSpinBox>
#include <QVariant>

#include <QBrush>
#include <QGroupBox>


#include "renderarea.h"

class Control;

namespace Ui {
class View;
}

class View : public QMainWindow
{
    Q_OBJECT

public:
    explicit View(QWidget *parent = 0);
    ~View();

    void setControl(Control *control) {
        this->control = control;
    }



private slots:

    void saveImage();
    void openImage();
    void newImage();
    void print();
    void quit();

    void on_Line_clicked();

    void on_Libre_clicked();

    void on_Rec_clicked();

    void on_Cercle_clicked();

    void on_Brosse_clicked();

    void on_pushButton_clicked();

private:
    Ui::View *ui;
    QColor couleur;
    Control *control;
    QString nomFichier;
    RenderArea *renderArea;
    QLabel *shapeLabel;
   QLabel *penWidthLabel;
    QLabel *penStyleLabel;
    QLabel *penCapLabel;
    QLabel *penJoinLabel;
    QLabel *brushStyleLabel;
    QLabel *otherOptionsLabel;
    QComboBox *shapeComboBox;
    QSpinBox *penWidthSpinBox;
    QComboBox *penStyleComboBox;
    QComboBox *penCapComboBox;
    QComboBox *penJoinComboBox;
    QComboBox *brushStyleComboBox;
    QCheckBox *antialiasingCheckBox;
    QCheckBox *transformationsCheckBox;
};

#endif // VIEW_H
